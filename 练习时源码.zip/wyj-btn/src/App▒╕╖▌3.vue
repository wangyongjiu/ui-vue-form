<template>
  <div id="app">
    <!-- 通过v-model 来控制按钮的开关 -->
    <!-- <hm-switch v-model="active"></hm-switch> -->
    <!-- <hm-switch v-model="active" active-color="#13ce66" inactive-color="green" name="username"></hm-switch> -->

    <!-- radio 通过label 和 v-model 一起来控制选中状态 -->
    <hm-radio label="1" v-model="gender">男</hm-radio>
    <hm-radio label="0" v-model="gender">女</hm-radio>

    <hm-radio-group v-model="genders">
      <hm-radio label="1">男</hm-radio>
      <hm-radio label="0">女</hm-radio>
    </hm-radio-group>

  </div>
</template>

<script>
export default {
    data(){
      return {
        active:false,
        gender:'1',
        genders:'1'
      }
    }
}
</script>

<style lang="scss" scoped>

</style>
