<template>
  <div id="app">
    <!-- <hm-input placeholder="请输入手机号" type="Number" name="username"></hm-input>
    <hm-input placeholder="请输入用户名" type="password" name="username" disabled></hm-input> -->
    
    <hm-input placeholder="请输入用户名" v-model="val" clearable></hm-input>
    <hm-input placeholder="请输入用户名" v-model="pass" type="password" showPassword></hm-input>

    <!-- v-model的实现原理 等价于 -->
    <!-- <input type="text" :value="val" @input="val=$event.target.value"> -->

  </div>
</template>

<script>
export default {
    data(){
      return{
        val:'zs',
        pass:'adasdas'
      }
    }
}
</script>

<style lang="scss" scoped>
.hm-input{
  width: 30%;
}
</style>
