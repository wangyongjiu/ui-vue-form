<template>
  <div id="app">
    <hm-checkbox v-model="active">是否选中</hm-checkbox>

    <hm-checkbox-group v-model="hobby">
      <hm-checkbox label="抽烟"></hm-checkbox>
      <hm-checkbox label="喝酒"></hm-checkbox>
      <hm-checkbox label="烫头"></hm-checkbox>
    </hm-checkbox-group>
  </div>
</template>

<script>
export default {
    data(){
      return {
        active:false,
        gender:'1',
        genders:'1',
        hobby:['抽烟','喝酒','烫头']
      }
    }
}
</script>

<style lang="scss" scoped>

</style>
