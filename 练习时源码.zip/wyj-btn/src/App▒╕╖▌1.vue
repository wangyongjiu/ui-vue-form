<template>
  <div id="app">
    <HmButton type="success">按钮1</HmButton>
    <HmButton plain type="success" @click="visible=true;">显示弹框</HmButton>
    <HmButton round plain type="success">按钮2</HmButton>
    <HmButton circle plain type="success" @click="fn">21</HmButton>
    <HmButton disabled circle type="success" @click="fn">21</HmButton><br/>
    <hm-button icon="glyphicon-plus"></hm-button>
    <!-- 子组件传过来的close方法 在此需要绑定这个方法然后执行他，点击事件是在子组件操作的，这里不要糊涂，要明白-->
    <!-- <hm-dialong width="40%" top="20px" title="我来温馨提示" :visible="visible" @close="close"></hm-dialong> -->
    <!-- sync修饰符是一个语法糖 用了.sync就可以不用写close方法了在父组件中-->
    <hm-dialong width="40%" top="20px" title="我来温馨提示" :visible.sync="visible">
      <ul>
        <li>好嗨呦，感觉人生已经达到了高潮！</li>
        <li>好嗨呦，感觉人生已经达到了巅峰！</li>
      </ul>
      <!-- 有名字的插槽的传模板的方式
      必须要写template ,其次用到v-slot指令  接上:footer , footer是dialong.vue组件预留插槽的名字 -->
      <template v-slot:footer>
        <hm-button @click="visible=false;">取消</hm-button>
        <hm-button type="primary" @click="visible=false;">确定</hm-button>
      </template>
    </hm-dialong>
    <!-- <hm-dialong>
      <template v-slot:title>
        <h3>温馨提示</h3>
      </template>
    </hm-dialong> -->

    

  </div>
</template>

<script>
export default {
  data(){
    return{
      visible:false
    }
  },
  methods:{
    fn(){
      console.log('打印,除了icon图标外，按钮组件封装完毕！');
    },
    close(value){
      this.visible=value;
    }
  }
}
</script>

<style lang="scss">

</style>
