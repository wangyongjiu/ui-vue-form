<template>
  <div id="app">
    <hm-button type="primary">按钮</hm-button>
  </div>
</template>

<script>

export default {
}
</script>

<style lang="scss">
</style>
